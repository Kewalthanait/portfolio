//Navigation bar effects non scroll
window.addEventListener("scroll", function(){
const header=document.querySelector("header");
header.classList.toggle("sticky", window.scrollY > 0);
});
//service section
const serviceModals = document.querySelectorAll(".service-modal");
const learnmoreBtns = document.querySelectorAll(".learn-more-btn");
const modalCloseBtns = document.querySelectorAll(".modal-close-btn");

const openModal = function(modalIndex) {
    serviceModals[modalIndex].classList.add("active");
}

const closeModal = function() {
    serviceModals.forEach((modalView) => {
        modalView.classList.remove("active");
    });
}

// Attach event listeners to "Learn More" buttons
learnmoreBtns.forEach((learnmoreBtn, i) => {
    learnmoreBtn.addEventListener("click", () => {
        openModal(i);
    });
});

// Attach event listeners to modal close buttons
modalCloseBtns.forEach((modalCloseBtn) => {
    modalCloseBtn.addEventListener("click", closeModal);
});
// ---------------portfolio section--------------=================
const portfolioModals = document.querySelectorAll(".portfolio-model");
const imageCards = document.querySelectorAll(".img-card");
const portfolioCloseBtns = document.querySelectorAll(".portfolio-close-btn");

// Function to open a specific modal
const openModalportfolio = function(modalIndex) {
    portfolioModals[modalIndex].classList.add("active");
}

// Function to close all modals
const closeModalportfolio = function() {
    portfolioModals.forEach((modalView) => {
        modalView.classList.remove("active");
    });
}

// Attach event listeners to image cards
imageCards.forEach((imageCard, i) => {
    imageCard.addEventListener("click", () => {
        openModalportfolio(i);
    });
});

// Attach event listeners to modal close buttons
portfolioCloseBtns.forEach((portfolioCloseBtn) => {
    portfolioCloseBtn.addEventListener("click", closeModalportfolio);
});
//our-client-swiper
var swiper = new Swiper(".client-swiper", {
    slidesPerView: 1,
    spaceBetween: 30,
    loop: true,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });
  //website dark/light theme

const themeBtn = document.querySelector(".theme-btn");
const getCurrentTheme = () => document.body.classList.contains("dark-theme") ? "dark" : "light";
const getCurrentIcon = () => themeBtn.classList.contains("sun") ? "sun" : "moon";
themeBtn.addEventListener("click", () => {
    document.body.classList.toggle("dark-theme");
    themeBtn.classList.toggle("sun");    
    localStorage.setItem("saved-theme", getCurrentTheme());
    localStorage.setItem("saved-icon", getCurrentIcon());
});


const savedTheme = localStorage.getItem("saved-theme");
const savedIcon = localStorage.getItem("saved-icon");

if (savedTheme) {
    document.body.classList[savedTheme === "dark" ? "add" : "remove"]("dark-theme");
}
if (savedIcon) {
    themeBtn.classList[savedIcon === "sun" ? "add" : "remove"]("sun");
}

  // scroll to top button
  const scrollTopBtn = document.querySelector(".scrollToTop-btn");
  window.addEventListener("scroll", function(){
    scrollTopBtn.classList.toggle("active", window.scrollY > 500);
  });
  scrollTopBtn.addEventListener("click", () => {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  });
  //Navigation menu items active on page scroll

window.addEventListener("scroll", () => {
    const sections = document.querySelectorAll("section");
    const scrollY = window.pageYOffset;

    sections.forEach(current => {
        let sectionHeight = current.offsetHeight;
        let sectionTop = current.offsetTop - 50; // Adjust offset as needed
        let id = current.getAttribute("id");
        let navLink = document.querySelector(`.nav-items a[href*="${id}"]`);

        if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
            navLink.classList.add("active");
        } else {
            navLink.classList.remove("active");
        }
    });
});
//Responsive navigation menu toggle
const menuBtn = document.querySelector(".nav-menu-btn");
const closeBtn = document.querySelector(".nav-close-btn");
const navigation = document.querySelector(".navigation");
const navItems= document.querySelectorAll(".nav-items a");


menuBtn.addEventListener("click", () => {
navigation.classList.add("active");
});
closeBtn.addEventListener("click", () => {
    navigation.classList.remove("active");
    });
    
navItems.forEach((navItem) => {
  navItem.addEventListener("click", () =>{
    navigation.classList.remove("active");
  });
});
// scroll reveal animations 
// common reveal options 
ScrollReveal({
    reset: true,
    distance: '60px',
    duration: 2500,
    delay: 100
 });
 //typing text
 const text = document.querySelector(".second-text");
const roles = ["Freelancer", "Content Writer", "Web Developer", "Teacher"];
const changeInterval = 4000;

const textLoad = () => {
    roles.forEach((role, index) => {
        setTimeout(() => {
            text.textContent = role;
        }, index * changeInterval);
    });
};

// Start the first load and then repeat every 16 seconds
textLoad();
setInterval(textLoad, roles.length * changeInterval);

 // target emements , and specify options 
 ScrollReveal().reveal('.home .info h2, .section-title-01, .section-title-02', {delay: 500 , origin: 'left'});
 ScrollReveal().reveal('.home .info h3, .home .info p, .aboat-info .btn', {delay: 600 , origin: 'right'});
 ScrollReveal().reveal('.home .info .btn', {delay: 700 , origin: 'bottom'});
 ScrollReveal().reveal('.media-icons i, .contact-left li', {delay: 500 , origin: 'left', interval: 200 });
 ScrollReveal().reveal('.home-img, .about-img', {delay: 500 , origin: 'bottom' });
 ScrollReveal().reveal('.about .description, .copy-right', {delay: 600 , origin: 'right' });
 ScrollReveal().reveal('.about .professional-list li ', {delay: 500 , origin: 'right',interval: 200 });
 ScrollReveal().reveal('.skills-description,.services, .service-description, .service-list, .skills-info, .btn, .education, .contact-card, .client-swiper, .contact-left h2', {delay: 700 , origin: 'left'});
 ScrollReveal().reveal('.contact-right', {delay: 700 , origin: 'right'});
 ScrollReveal().reveal('.first-row, .second-row, .third-row', {delay: 500 , origin: 'right'});
 ScrollReveal().reveal('.service-list', {delay: 700 , origin: 'bottom'});
 ScrollReveal().reveal('.experience-card, .service-card, .education, .portfolio, .img-card', {delay: 800 , origin: 'bottom', interval: 200});
 ScrollReveal().reveal('footer .group', {delay: 500 , origin: 'top', interval: 200});

 